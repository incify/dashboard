v.1.0.2

* Add new layout Six
* Fixed scroll on firefox on fixed content mode

v.1.0.1

* Fixed scroll content on touch screen
