(function ($) {
	'use strict';
})(jQuery);
